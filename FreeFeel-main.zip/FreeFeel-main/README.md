# FreeFeel

about
=> Its a confession page website where one can share secrets anonymously and read others confessions by signup/login.
user can update his profile also.


future updates

=> user can like confession

=> user can comment at confession

=> user can comment by tagging other users



Installation

=> Open Terminal and run following commands (make sure you have installed node.js already)

-> git clone git@github.com:viyaaat/FreeFeel.git

-> npm install

-> npm start

=>Go to Browser and open localhost:3000

